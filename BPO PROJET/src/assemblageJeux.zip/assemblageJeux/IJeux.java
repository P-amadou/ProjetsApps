/*@author TRAN L�o, DIEYE Papa Amadou
 * @version 1.0
 */
package assemblageJeux;

/*@brief Interface des jeux
 */
public interface IJeux {
	/*@brief
	 * @return retourne si la partie est gagn�e ou non
	 */
	boolean jouer(String[] args);
}
