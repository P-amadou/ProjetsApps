/*@author TRAN L�o, DIEYE Papa Amadou
 * @version 1.0
 */
package assemblageJeux;

public class AppliJeux {

	public static void main(String[] args) {
//		LJeux Jeux = new LJeux();
//		IJeux jeu = new Assembler1_1(new IJeux(), new IJeux());
//		jeu.jouer(args);
		
		
//		Jeux.listeJeux.add(jeu);
//		Jeux.listeJeux.add(new Assembler1_1(Jeux.listeJeux.get(x),Jeux.listeJeux.get(y))
//		Jeux.listeJeux.get(i).jouer(args);

	}

}
